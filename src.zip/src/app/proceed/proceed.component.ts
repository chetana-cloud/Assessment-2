import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proceed',
  templateUrl: './proceed.component.html',
  styleUrls: ['./proceed.component.css']
})
export class ProceedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
